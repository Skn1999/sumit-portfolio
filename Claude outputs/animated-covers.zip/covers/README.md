# Animated case-study covers

Four seamless loops, coded in HTML/CSS/JS and rendered to video.

| Cover | Loop | Story |
|---|---|---|
| `ediaqi` | 8 s | CO₂ climbs → the display says what to do → recovery is tracked back to good air |
| `dashboard` | 8 s | 10 s of skeletons → widgets load on their own in 0.8 s → one update touches one widget |
| `aplus` | 8 s | one major issue vs. minor ones from users with disabilities → the minors outweigh it |
| `you` | 8.5 s | open the phone for the weather → 23 min of drift → YOU nudges at the moment of drift |

## Files

- `public/v2/covers/*.mp4` — 1280×720 H.264 for the site (~220–330 KB each). Use `muted loop playsinline autoplay` + `poster`.
- `public/v2/covers/*-poster.jpg` — the still for reduced motion and while the video loads.
- `cover-animations/exports/*-1080.mp4` — 1920×1080 masters.
- `cover-animations/exports/*.gif` — 720 px GIFs for LinkedIn, Read.cv, email.
- `cover-animations/source/` — the animations. Open any `.html` in a browser to watch it loop.

## Editing and re-rendering

Every frame is drawn from a single time value `t`, in `COVER.frame(t)` at the bottom of each file, so timing
changes are made in one place. To re-render:

```bash
cd cover-animations/source
npm i playwright && npx playwright install chromium   # once
node render.js ediaqi dashboard aplus you             # needs ffmpeg; writes ./out
node strip.js ediaqi 8                                # quick 8-frame contact sheet
```

## On the site

```html
<video src="/v2/covers/ediaqi.mp4" poster="/v2/covers/ediaqi-poster.jpg"
       muted loop playsinline autoplay preload="metadata"></video>
```

Pause the video when it is off screen (IntersectionObserver) and show only the poster under `prefers-reduced-motion`.
